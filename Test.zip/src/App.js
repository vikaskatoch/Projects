import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <div class="One">
        <div class="material">
          <div class="image">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSAKPJu3L_qyPJvB6OkfbS5NtpJPAfTxZCyYdPYVUV3cg&s" />
          </div>

          <div class="inside">
            <h4 class="header-one">An email has been sent to you</h4>
            <p class="para">
              Check the email that`s associated with your account for the
              verification code
            </p>
          </div>
          <div>
            <h5 class="vercode">Verification code</h5>
            <input class="inputt" type="text" />
            <button class="btn">Verify</button>

            <p class="text">Send me another code</p>
            <p class="text">Skip for now ></p>
          </div>
        </div>
      </div>
    </div>
  );
}
